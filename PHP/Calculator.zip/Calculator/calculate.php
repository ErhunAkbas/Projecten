<!doctype html>
<html>
<head>
	<title>calculator</title>
	<link rel="stylesheet" href="style.css" type="text/css">
</head>
<body>
	<div class="frame">
		<h1>Calculator</h1>
		<?php echo $_POST['getal1'] ;?> 
		<?php echo $_POST['operator'];?> 
		<?php echo $_POST['getal2']; ?>
		<?php $atwoord = "=";?>
		<a href="index.html"><button>Volgende berekening</button></a>
	</div>
</body>
</html>