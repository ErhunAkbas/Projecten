require 'robot_arm'
robot_arm: random_level(4)
robot_arm.speed = 0.90

print("Welke kolom moet worden verplaatst? Je kunt kiezen uit 1 t/m 4")
answer = string.lower(io.read())

  if answer ==  "1"  then
   for k = 1,4 do
     robot_arm:grab()
    for i = 1,8 do
      robot_arm:move_right()
    end
    robot_arm:drop()
    for j = 1,8 do
      robot_arm:move_left()
    end
  end
end
