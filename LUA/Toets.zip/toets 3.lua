print("Wat is de code")
answer = io.read()

if answer == "simsalabim" then
  print("De deur gaat open")
else
  print("De deur bijft dicht!")
end
