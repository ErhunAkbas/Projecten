for i = 1, 10 do
  print ("1")
end
voorbeeld