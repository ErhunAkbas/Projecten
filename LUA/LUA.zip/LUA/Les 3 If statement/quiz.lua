print("hoe heet je?")
Name = io.read()

if Name == "Arnold" then
  print("je bent toffe gozer.")
elseif Name == ("Peter") then
  print("jij bent raar")
elseif Name == ("Erhun") then
  print("jij bent een goed gozer")
else
  print("jou ken ik niet")
end