print("Is het geel")
Answer = io.read()
if Asnwer == "ja" then
 print("Kun je er op staan?")
Answer = io.read()
if Answer == "nee" then
 print("De zon") 
else
 print("Een kuikentje.")
end
 
   Answer = io.read()
   if Answer == "nee" then
    print("Is het groot?")
  end
  Answer = io.read()
   if Answer == ("ja") then
    print("Een olifant")
   else
    print("Een muis")
  end
end
