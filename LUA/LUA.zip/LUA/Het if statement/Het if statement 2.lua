print("hoe oud ben je")
Age = tonumber(io.read())

if Age < 18 then
  print(Age .. " is niet erg oud")
else
  print("Ben je al " .. Age)
  print("Dat zou je niet zeggen")
end