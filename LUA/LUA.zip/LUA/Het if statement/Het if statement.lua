print("hoe heet je")
Name = io.read()
print("Hallo, " .. Name)

if Name == "Arnold" then
   print("Je bent een toffe gozer")
else
  print("Jou ken ik niet")
end
