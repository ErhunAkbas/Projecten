for i = 1,5 do
  print('hallo')
 end