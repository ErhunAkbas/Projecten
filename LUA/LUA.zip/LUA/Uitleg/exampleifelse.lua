print("Is het geel?")
Answer = io.read()

if Answer == "ja" then
  print("1 ja")
  if 
    print("1 ja, 2 ja")
  else
    print("1 ja, 2 nee")
  end
else
  print("1 nee")
  
  if
    print("vraag1 nee, vraag 2 ja "
  else
end

end
  
  
  
  Answer = io.read()
  if Answer == "nee" then
    print("Is het groot?")
  end