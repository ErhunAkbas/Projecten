print("hoe heet je")
pa = io.read()
print("Hallo, " .. pa)



