for i = 1,10 do 
  print(i)
end
