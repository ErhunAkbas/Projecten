print("Is het geel")
answer = io.read() 
 if answer == "ja" then
   print("kun je er op staan")
   answer = io.read()
  if answer == "ja" then
   print("een kuikentje")
  elseif answer == "nee" then
   print("de zon")
   end

elseif answer == "nee" then
 print("is het groot")
 answer = io.read()
 if answer == "ja" then
   print("een olifant")
 elseif answer == "nee" then
   print("een muis")     
   end
end