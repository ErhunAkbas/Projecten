for i = 1, 10 do   
  for j = 1, 10 do 
  
  
  
  
  
  end
end
