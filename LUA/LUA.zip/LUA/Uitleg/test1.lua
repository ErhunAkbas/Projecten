print("Is de kaas geel")
answer = string.lower(io.read())

if answer == "ja" then
  print("Zitten er gaten in?") 
  answer = string.lower(io.rad())
  if  answer == "nee" then
  
  end

elseif answer == "nee" then


else
  print("kies tussen ja en nee")



end
